const { useState } = React;

// Satirisch, fictief spel. Alle personen en munten zijn karikaturen.
// Er is geen echte politiek advies en geen echt geld.

const QUESTIONS = [
  {
    id: 1,
    text:
      "Je komt een groot scherm tegen. Daarop staat: 'De wereld werkt hard en houdt samen, maar valt aan de randen uit elkaar.' Wat doe je?",
    options: [
      {
        id: "a",
        label: "Ik klik direct op de grote knop 'Volg de Leider'.",
        effect: 3,
      },
      {
        id: "b",
        label: "Ik lees eerst de kleine letters onderaan het scherm.",
        effect: 2,
      },
      {
        id: "c",
        label: "Ik sluit alles en ga koffie drinken.",
        effect: 1,
      },
    ],
  },
  {
    id: 2,
    text:
      "De karikatuur-leider vertelt: 'De cirkel heeft geen middelpunt, de fles is leeg, maar ik heb het plan!' Hoe reageer je?",
    options: [
      {
        id: "a",
        label: "Ik juich. Leeg of niet, als hij het zegt zal het wel kloppen.",
        effect: 3,
      },
      {
        id: "b",
        label: "Ik vraag rustig: 'Kun je dat uitleggen?'.",
        effect: 2,
      },
      {
        id: "c",
        label: "Ik trek mijn eigen cirkel en vul mijn eigen fles.",
        effect: 1,
      },
    ],
  },
  {
    id: 3,
    text:
      "Alle spelers in het chatvenster krijgen een rol. Welke rol kies jij?",
    options: [
      {
        id: "a",
        label: "Digitale dummy: ik laat alles door de leider klikken.",
        effect: 3,
      },
      {
        id: "b",
        label: "Twijfelaar: ik luister, maar stel vragen.",
        effect: 2,
      },
      {
        id: "c",
        label: "Denker: ik klik alleen na goed nadenken.",
        effect: 1,
      },
    ],
  },
  {
    id: 4,
    text:
      "In het spel verschijnen glanzende, imaginaire munten: 'Mining-Moe-Coin'. Wat doe je?",
    options: [
      {
        id: "a",
        label:
          "Ik verzamel zoveel mogelijk, zonder te vragen waar ze vandaan komen.",
        effect: 3,
      },
      {
        id: "b",
        label: "Ik vraag wie beslist hoe de munten worden verdeeld.",
        effect: 2,
      },
      {
        id: "c",
        label: "Ik herinner iedereen dat de munten verzonnen zijn.",
        effect: 1,
      },
    ],
  },
  {
    id: 5,
    text:
      "De leider roept: 'Met genoeg klikken blazen we elke beurs op deze planeet omver!' Hoe voelt dat voor jou?",
    options: [
      {
        id: "a",
        label: "Klinkt fantastisch, ik klik sneller!",
        effect: 3,
      },
      {
        id: "b",
        label: "Ik lach en weet dat het maar een spel is.",
        effect: 2,
      },
      {
        id: "c",
        label:
          "Ik zeg: 'Misschien moeten we eerst leren hoe geld echt werkt.'",
        effect: 1,
      },
    ],
  },
];

function getResult(score) {
  if (score >= 13) {
    return {
      title: "Super-Dummy-Volgeling",
      description:
        "Je laat je graag leiden door grote woorden en heldere slogans. In dit spel klik je vooral waar de karikatuur-leider dat wil. Een vriendelijke reminder: in de echte wereld mag je altijd zelf nadenken.",
    };
  }
  if (score >= 9) {
    return {
      title: "Twijfelende Volger",
      description:
        "Je luistert naar de leider, maar ergens diep vanbinnen hoor je ook je eigen stem. In dit spel balanceer je tussen meeklappen en vragen stellen.",
    };
  }
  return {
    title: "Eigenwijze Denker",
    description:
      "Je laat je niet zomaar sturen, ook niet door een luidruchtige karikatuur. In dit spel ben je de speler die het lege flesje en de cirkel zonder middelpunt in vraag stelt.",
  };
}

function DummyLeiderSpel() {
  const [stage, setStage] = useState("intro"); // intro | uitleg | spel | resultaat
  const [currentIndex, setCurrentIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [answers, setAnswers] = useState([]);

  const currentQuestion = QUESTIONS[currentIndex];

  function handleStart() {
    setStage("uitleg");
  }

  function handleBeginGame() {
    setStage("spel");
    setCurrentIndex(0);
    setScore(0);
    setAnswers([]);
  }

  function handleAnswer(option) {
    const newScore = score + option.effect;
    setScore(newScore);
    setAnswers([...answers, { questionId: currentQuestion.id, optionId: option.id }]);

    if (currentIndex + 1 < QUESTIONS.length) {
      setCurrentIndex(currentIndex + 1);
    } else {
      setStage("resultaat");
    }
  }

  function handleRestart() {
    setStage("intro");
    setCurrentIndex(0);
    setScore(0);
    setAnswers([]);
  }

  const totalMaxScore = QUESTIONS.length * 3;
  const minedCoins = score * 10; // fictieve muntjes

  return (
    React.createElement("div", { className: "page" },
      React.createElement("div", { className: "card" },
        React.createElement("header", { className: "header" },
          React.createElement("div", { className: "header-left" },
            React.createElement("h1", null, "Dummy-Leider Chatspel (Satirische Karikatuur)"),
            React.createElement("p", null,
              "Dit is een eenvoudige, satirische webgame in het Nederlands. Alles is fictief, alle munten zijn verzonnen en het spel is bedoeld om na te denken over volgen en zelf denken in een digitale wereld."
            )
          ),
          React.createElement("div", { className: "header-right" },
            React.createElement("p", { className: "producer-label" }, "Producer-informatie:"),
            React.createElement("a", {
              href: "https://tel1.nl",
              target: "_blank",
              rel: "noreferrer",
              className: "producer-link",
            }, "TEL1.N\u0308\u0139")
          )
        ),

        stage === "intro" && (
          React.createElement("section", { className: "section" },
            React.createElement("div", { className: "panel" },
              React.createElement("p", { className: "panel-title" }, "Po\u00ebtische opening van het spel:"),
              React.createElement("p", { className: "poem" },
                "Ik lach me kapot in deze wereld", React.createElement("br", null),
                "die werkt en samenhoudt,", React.createElement("br", null),
                "en ondertussen aan de randen uit elkaar valt.", React.createElement("br", null),
                "De passer heeft geen prikpunt,", React.createElement("br", null),
                "het vlak bestaat niet,", React.createElement("br", null),
                "geen volume,", React.createElement("br", null),
                "de fles is leeg."
              )
            ),
            React.createElement("div", { className: "text-block" },
              React.createElement("p", null,
                "In dit spel verschijnt een karikatuur-leider in een digitale chatwereld. Hij beweert precies te weten waar iedereen op moet klikken. De spelers zijn digitale dummies, twijfelaars en denkers."
              ),
              React.createElement("p", null,
                "Je hebt maar \u00e9\u00e9n taak: rustig lezen en af en toe op een grote knop drukken. Dat is alles. Zelfs als je nog nooit een spel hebt gespeeld, kun je dit."
              )
            ),
            React.createElement("button", {
              onClick: handleStart,
              className: "btn-primary",
            }, "\ud83d\udc49 Start: simpele uitleg stap voor stap")
          )
        ),

        stage === "uitleg" && (
          React.createElement("section", { className: "section" },
            React.createElement("h2", null, "Hoe werkt dit spel?"),
            React.createElement("ol", { className: "list" },
              React.createElement("li", null, "Je ziet telkens ", React.createElement("strong", null, "\u00e9\u00e9n vraag"), " op het scherm."),
              React.createElement("li", null, "Onder de vraag staan ", React.createElement("strong", null, "drie grote knoppen"), "."),
              React.createElement("li", null, "Lees de tekst op de knoppen rustig. Klik dan op de knop die het best bij jou past."),
              React.createElement("li", null, "Het spel telt op de achtergrond punten. Jij hoeft niets te rekenen."),
              React.createElement("li", null, "Aan het einde zie je een uitslag en hoeveel imaginaire munten je hebt \"gemined\".")
            ),
            React.createElement("div", { className: "panel" },
              React.createElement("p", { className: "panel-title" }, "Belangrijk om te weten:"),
              React.createElement("ul", { className: "list" },
                React.createElement("li", null, "Dit is een ", React.createElement("strong", null, "karikatuur"), ", geen echte politiek."),
                React.createElement("li", null,
                  "De \"Mining-Moe-Coins\" in het spel zijn ",
                  React.createElement("strong", null, "100% verzonnen"),
                  " en hebben geen echte waarde."
                ),
                React.createElement("li", null,
                  "Als je deze code later deelt of aanpast, heb je een echte betaal- of blockchain-dienst nodig voor echt geld. Dat zit ",
                  React.createElement("strong", null, "niet"),
                  " in dit spel."
                )
              )
            ),
            React.createElement("div", { className: "buttons-row" },
              React.createElement("button", {
                onClick: handleBeginGame,
                className: "btn-primary",
              }, "\ud83c\udfae Begin nu met spelen"),
              React.createElement("button", {
                onClick: handleRestart,
                className: "btn-secondary",
              }, "\u2b05\ufe0f Terug naar begin")
            )
          )
        ),

        stage === "spel" && currentQuestion && (
          React.createElement("section", { className: "section" },
            React.createElement("div", { className: "meta-row" },
              React.createElement("p", null,
                "Vraag ", currentIndex + 1, " van ", QUESTIONS.length
              ),
              React.createElement("p", null,
                "Fictieve mining-munten: ",
                React.createElement("strong", null, minedCoins),
                " Moe-Coins"
              )
            ),
            React.createElement("div", { className: "panel" },
              React.createElement("p", { className: "question" }, currentQuestion.text),
              React.createElement("div", { className: "options" },
                currentQuestion.options.map((option) =>
                  React.createElement("button", {
                    key: option.id,
                    onClick: () => handleAnswer(option),
                    className: "btn-option",
                  },
                    React.createElement("span", { className: "bullet" }, "\u25cf"),
                    option.label
                  )
                )
              )
            ),
            React.createElement("p", { className: "hint" },
              "Tip: Er is geen goede of foute klik. Het spel laat alleen zien hoe jij reageert op een luidruchtige digitale leider."
            )
          )
        ),

        stage === "resultaat" && (
          React.createElement("section", { className: "section" },
            React.createElement("h2", null, "Jouw resultaat in deze karikatuurwereld"),
            React.createElement("div", { className: "panel" },
              (() => {
                const result = getResult(score);
                return (
                  React.createElement(React.Fragment, null,
                    React.createElement("p", { className: "result-title" }, result.title),
                    React.createElement("p", { className: "result-text" }, result.description)
                  )
                );
              })(),
              React.createElement("div", { className: "result-meta" },
                React.createElement("p", null,
                  "Totaal spelpunten: ",
                  React.createElement("strong", null, score),
                  " van ",
                  totalMaxScore
                ),
                React.createElement("p", null,
                  "Fictief gemined: ",
                  React.createElement("strong", null, minedCoins),
                  " Mining-Moe-Coins"
                )
              ),
              React.createElement("div", { className: "dev-note" },
                React.createElement("p", { className: "panel-title" }, "Voor ontwikkelaars en knutselaars:"),
                React.createElement("ul", { className: "list" },
                  React.createElement("li", null, "Je kunt deze pagina als statische site hosten (alleen HTML + JavaScript)."),
                  React.createElement("li", null,
                    "Voor echte betalingen, wallets of blockchain heb je een eigen back-end of externe dienst nodig (bijv. Stripe, iDEAL, een blockchain-node, enz.)."
                  ),
                  React.createElement("li", null,
                    "Voeg daar dan functies toe waar nu alleen de fictieve \"Mining-Moe-Coins\" staan."
                  )
                )
              )
            ),
            React.createElement("div", { className: "buttons-row" },
              React.createElement("button", {
                onClick: handleBeginGame,
                className: "btn-primary",
              }, "\ud83d\udd01 Speel nog een keer"),
              React.createElement("button", {
                onClick: handleRestart,
                className: "btn-secondary",
              }, "\u2b05\ufe0f Terug naar de po\u00ebtische start")
            ),
            React.createElement("p", { className: "hint" },
              "Je kunt deze bestanden met anderen delen zodat zij hun eigen karikatuur-chatwereld maken. Elke speler kan de vragen en teksten aanpassen aan zijn of haar eigen spelgewoonten."
            )
          )
        )
      )
    )
  );
}

function App() {
  return React.createElement(DummyLeiderSpel);
}

// Minimal styling injected via JS
const style = document.createElement("style");
style.textContent = `
  .page {
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 16px;
    background: #020617;
    color: #e2e8f0;
  }
  .card {
    width: 100%;
    max-width: 960px;
    background: #020617;
    border-radius: 18px;
    border: 1px solid #1f2937;
    padding: 24px;
    box-shadow: 0 20px 45px rgba(15, 23, 42, 0.8);
  }
  .header {
    border-bottom: 1px solid #1f2937;
    padding-bottom: 16px;
    margin-bottom: 16px;
    display: flex;
    flex-direction: column;
    gap: 12px;
  }
  @media (min-width: 768px) {
    .header {
      flex-direction: row;
      justify-content: space-between;
      align-items: flex-start;
    }
  }
  .header-left h1 {
    font-size: 1.8rem;
    margin: 0 0 4px 0;
  }
  .header-left p {
    margin: 0;
    font-size: 0.95rem;
    color: #cbd5f5;
  }
  .producer-label {
    margin: 0;
    color: #94a3b8;
    font-size: 0.8rem;
  }
  .producer-link {
    display: inline-flex;
    margin-top: 4px;
    font-size: 0.85rem;
    color: #6ee7b7;
    text-decoration: none;
  }
  .producer-link:hover {
    text-decoration: underline;
  }
  .section {
    display: flex;
    flex-direction: column;
    gap: 16px;
    margin-top: 8px;
  }
  .panel {
    background: rgba(15, 23, 42, 0.9);
    border-radius: 14px;
    border: 1px solid #1f2937;
    padding: 16px;
  }
  .panel-title {
    font-weight: 600;
    margin: 0 0 8px 0;
  }
  .poem {
    margin: 0;
    font-style: italic;
    line-height: 1.5;
  }
  .text-block p {
    margin: 0 0 8px 0;
    font-size: 0.95rem;
  }
  .btn-primary, .btn-secondary {
    border-radius: 999px;
    padding: 10px 18px;
    border: none;
    cursor: pointer;
    font-weight: 600;
    font-size: 0.95rem;
    box-shadow: 0 10px 25px rgba(16, 185, 129, 0.3);
  }
  .btn-primary {
    background: #22c55e;
    color: #020617;
  }
  .btn-primary:hover {
    background: #4ade80;
  }
  .btn-secondary {
    background: transparent;
    color: #e2e8f0;
    border: 1px solid #4b5563;
    box-shadow: none;
  }
  .btn-secondary:hover {
    background: #111827;
  }
  .buttons-row {
    display: flex;
    flex-direction: column;
    gap: 8px;
  }
  @media (min-width: 640px) {
    .buttons-row {
      flex-direction: row;
    }
  }
  .list {
    margin: 0;
    padding-left: 18px;
    font-size: 0.9rem;
  }
  .list li {
    margin-bottom: 4px;
  }
  .meta-row {
    display: flex;
    justify-content: space-between;
    font-size: 0.8rem;
    color: #94a3b8;
  }
  .question {
    font-size: 1rem;
    font-weight: 600;
    margin-bottom: 12px;
  }
  .options {
    display: flex;
    flex-direction: column;
    gap: 8px;
  }
  .btn-option {
    text-align: left;
    border-radius: 14px;
    border: 1px solid rgba(75, 85, 99, 0.7);
    background: #020617;
    padding: 10px 12px;
    cursor: pointer;
    font-size: 0.95rem;
  }
  .btn-option:hover {
    background: #111827;
  }
  .bullet {
    margin-right: 6px;
    font-weight: 700;
  }
  .hint {
    font-size: 0.8rem;
    color: #9ca3af;
  }
  .result-title {
    font-weight: 700;
    font-size: 1.05rem;
    margin: 0 0 4px 0;
  }
  .result-text {
    margin: 0 0 12px 0;
    font-size: 0.95rem;
  }
  .result-meta p {
    margin: 0 0 4px 0;
    font-size: 0.9rem;
  }
  .dev-note {
    margin-top: 12px;
    font-size: 0.85rem;
    color: #cbd5f5;
  }
`;
document.head.appendChild(style);

const rootElement = document.getElementById("root");
const root = ReactDOM.createRoot(rootElement);
root.render(React.createElement(App));
